USE pedal
--INTO Discount

INSERT INTO Discount( DiscountID, CouponName, [Percentage], StartDate, EndDate, IsActive, MembershipID)
VALUES ('1', 'PEDAL10','10','05-05-2020','08-05-2020','TRUE','1');

INSERT INTO Discount( DiscountID, CouponName, [Percentage], StartDate, EndDate, IsActive, MembershipID)
VALUES ('2', 'PEDAL25','25','07-10-2020','09-10-2020','FALSE','1');

INSERT INTO Discount( DiscountID, CouponName, [Percentage], StartDate, EndDate, IsActive, MembershipID)
VALUES ('3', 'PEDAL40','40','03-01-2020','04-15-2020','TRUE','1');

INSERT INTO Discount( DiscountID, CouponName, [Percentage], StartDate, EndDate, IsActive, MembershipID)
VALUES ('4', 'PEDAL50','50','01-01-2020','02-01-2020','TRUE','1');

INSERT INTO Discount( DiscountID, CouponName, [Percentage], StartDate, EndDate, IsActive, MembershipID)
VALUES ('5', 'PEDAL20','20','12-05-2019','12-31-2019','FALSE','1');

INSERT INTO Discount( DiscountID, CouponName, [Percentage], StartDate, EndDate, IsActive, MembershipID)
VALUES ('6', 'FIT35','35','08-15-2020','09-20-2020','TRUE','3');

INSERT INTO Discount( DiscountID, CouponName, [Percentage], StartDate, EndDate, IsActive, MembershipID)
VALUES ('7', 'FIT50','50','04-01-2020','05-20-2020','TRUE','3');

INSERT INTO Discount( DiscountID, CouponName, [Percentage], StartDate, EndDate, IsActive, MembershipID)
VALUES ('8', 'FIRSTTRIP30','30','01-01-2019','12-31-2020','TRUE','1');

INSERT INTO Discount( DiscountID, CouponName, [Percentage], StartDate, EndDate, IsActive, MembershipID)
VALUES ('9', 'ADVENTURE20','20','06-01-2019','06-20-2019','FALSE','2');

INSERT INTO Discount( DiscountID, CouponName, [Percentage], StartDate, EndDate, IsActive, MembershipID)
VALUES ('10', 'ADVENTURE30','30','10-01-2020','10-31-2020','FALSE','2');



--INTO StartUsersTrip 

